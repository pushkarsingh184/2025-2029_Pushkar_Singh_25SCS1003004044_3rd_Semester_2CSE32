# NetSage AI — Responsible AI Review Log

## Final review snapshot
- Total cases reviewed: 35/35
- Accepted: 30
- Edited: 4
- Rejected: 1
- AI/human agreement: 86%
- Human-corrected cases: 5

## Recorded human interventions

### NS-07 — Host configured with the wrong default gateway
- Decision: Edited
- Reviewer: Pushkar Singh
- Original diagnosis: Host default gateway does not match the subnet's real gateway address.
- Final diagnosis: Configured default gateway is outside the host subnet.
- Correction target: Root cause
- Final next command: `show ip dhcp binding`
- Final fix steps: Correct the gateway (or DHCP option 3); renew the lease; test an off-subnet destination.

### NS-13 — DHCP hands out the gateway address to a client
- Decision: Edited
- Reviewer: Pushkar Singh
- Original diagnosis: Duplicate IP address on the segment causing ARP contention.
- Final diagnosis: DHCP pool does not exclude the gateway address 10.10.0.1, allowing it to be leased to a client.
- Correction target: Root cause
- Final next command: `show ip dhcp binding`
- Final fix steps: Exclude the gateway address from the DHCP pool and verify the lease/binding state.

### NS-30 — Static NAT entry maps to the wrong inside host
- Decision: Rejected
- Reviewer: Pushkar Singh
- Original diagnosis: No deterministic rule matched the supplied evidence.
- Human review outcome: AI diagnosis not supported by sufficient evidence; human triage required.
- Correction target: Root cause / diagnosis acceptance
- Reference fault: The mapping points to 10.0.0.30 (printer) instead of web server 10.0.0.25.
- Next command: `show ip nat translations`
- Final action: Reject the unsupported diagnosis and require human triage.

### NS-11 — Clients on a remote VLAN receive no DHCP offer
- Decision: Edited
- Reviewer: Pushkar Singh
- Original diagnosis: DHCP relay configuration issue.
- Final diagnosis: VLAN 40 SVI is missing the ip helper-address, so DHCPDISCOVER broadcasts cannot reach the DHCP server.
- Correction target: Root cause
- Final next command: `show run interface Vlan40`
- Final fix steps: Set ip helper-address to the live DHCP server; verify routing to the server subnet.

### NS-28 — PAT translates nothing because inside/outside roles are missing
- Decision: Edited
- Reviewer: Pushkar Singh
- Original diagnosis: NAT translation is unavailable.
- Final diagnosis: NAT inside/outside roles are not configured on the relevant interfaces, so PAT cannot process the traffic.
- Correction target: Root cause
- Final next command: `show ip nat statistics`
- Final fix steps: Mark the relevant inside and outside interfaces; verify NAT translations after generating test traffic.
