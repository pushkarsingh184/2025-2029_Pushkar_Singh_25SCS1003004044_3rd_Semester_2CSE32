# Deterministic Rule Checker

The current NetSage application contains a TypeScript deterministic rule engine. It evaluates structured `signals`, not free-form model text. Each matched rule supplies an OSI layer, root cause, next command, fix steps and an explanation.

## Supported rule families
- L1: physical port down; wireless co-channel interference; low RSSI/coverage hole
- L2: access VLAN mismatch; trunk VLAN not allowed; native VLAN mismatch; err-disabled port; hidden SSID
- L3: SVI down; gateway mismatch; wrong subnet mask; duplicate IP; HSRP with no active peer; missing route/default route; OSPF adjacency/area issues; routing loop; NAT interface marking; NAT pool exhaustion
- L4: DHCP relay/no-offer/pool exhaustion/excluded infrastructure; ACL explicit deny/implicit deny/direction
- L7: DNS no response/wrong record; WLAN 802.1X/RADIUS authentication

The supplied problem statement specifically asks for checks such as duplicate IPs, wrong masks, gateway mismatch, interface down, missing VLAN and missing routes.

## Confidence
Rule confidence is an explainable calculation from rule weights. It is not a measured model-accuracy metric and is capped below certainty.

## Python companion
`tools/rule_checker.py` is a small standalone companion checker demonstrating deterministic checks over a JSON configuration. It is included because the problem statement names a Python checker as a submission deliverable. The production application itself currently performs the equivalent rule checking in TypeScript.
