export type OsiLayer =
  | "L1 Physical" | "L2 Data Link" | "L3 Network" | "L4 Transport" | "L7 Application";
export type Category = "VLAN" | "Gateway" | "DHCP" | "DNS" | "Routing" | "ACL" | "NAT" | "Wireless";
export type Severity = "Low" | "Medium" | "High" | "Critical";
export interface Evidence { command: string; output: string; }
export interface Signals {
  accessVlanMismatch?: boolean; trunkVlanNotAllowed?: boolean; nativeVlanMismatch?: boolean;
  portDown?: boolean; portErrDisabled?: boolean; svi_down?: boolean; gatewayIpMismatch?: boolean;
  hostSubnetMaskWrong?: boolean; duplicateIp?: boolean; hsrpNoActive?: boolean; dhcpNoOffer?: boolean;
  dhcpPoolExhausted?: boolean; dhcpRelayMissing?: boolean; dhcpExcludedGateway?: boolean;
  dnsNoResponse?: boolean; dnsWrongRecord?: boolean; dnsServerUnreachable?: boolean; noRouteToDest?: boolean;
  defaultRouteMissing?: boolean; ospfNoNeighbor?: boolean; ospfAreaMismatch?: boolean;
  routingLoopTtlExceeded?: boolean; aclDenyMatch?: boolean; aclImplicitDeny?: boolean;
  aclWrongDirection?: boolean; natNoTranslation?: boolean; natPoolExhausted?: boolean;
  natMissingInsideOutside?: boolean; wlanAuthFail?: boolean; wlanNoSsidBroadcast?: boolean;
  wlanChannelInterference?: boolean; wlanClientLowRssi?: boolean; pingFailsToGateway?: boolean;
  pingOkToGateway?: boolean; dnsResolvesButNoHttp?: boolean;
}
export interface TroubleshootingCase {
  id:string; title:string; category:Category; severity:Severity; symptoms:string; topology:string;
  evidence:Evidence[]; signals:Signals;
  reference:{rootCause:string; osiLayer:OsiLayer; nextCommand:string; fixSteps:string[]};
}
export type ReviewDecision = "Accepted" | "Edited" | "Rejected";
export interface Diagnosis {
  rootCause:string; confidence:number; osiLayer:OsiLayer; evidence:string[];
  nextCommand:string; fixSteps:string[]; source:"rules"; notes?:string;
}
export type CorrectionTarget =
  | "Root cause" | "OSI layer" | "Evidence use" | "Next command"
  | "Fix steps" | "Confidence calibration" | "Severity";
export interface Review {
  caseId:string; decision:ReviewDecision; reviewer:string; reviewedAt:string;
  aiRootCause:string; finalRootCause:string; finalOsiLayer:OsiLayer; finalNextCommand:string;
  finalFixSteps:string[]; comment?:string; correctionTargets:CorrectionTarget[]; source:Diagnosis["source"];
}
export const CORRECTION_TARGETS:CorrectionTarget[]=[
  "Root cause","OSI layer","Evidence use","Next command","Fix steps","Confidence calibration","Severity"
];
