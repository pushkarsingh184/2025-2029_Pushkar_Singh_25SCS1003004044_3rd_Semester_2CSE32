import { useCallback, useEffect, useState } from "react";
import type { Review } from "./types";
const KEY="netsage.reviews.v1"; const EVENT="netsage:reviews-changed";
function read():Review[]{if(typeof window==="undefined")return[];try{const raw=window.localStorage.getItem(KEY);return raw?(JSON.parse(raw) as Review[]):[];}catch{return[];}}
function write(reviews:Review[]){window.localStorage.setItem(KEY,JSON.stringify(reviews));window.dispatchEvent(new Event(EVENT));}
export function saveReview(review:Review){const others=read().filter(r=>r.caseId!==review.caseId);write([...others,review]);}
export function clearReviews(){write([]);}
export function useReviews(){const[reviews,setReviews]=useState<Review[]|null>(null);const sync=useCallback(()=>setReviews(read()),[]);
useEffect(()=>{sync();window.addEventListener(EVENT,sync);window.addEventListener("storage",sync);return()=>{window.removeEventListener(EVENT,sync);window.removeEventListener("storage",sync);};},[sync]);
return{reviews:reviews??[],loaded:reviews!==null};}
export function useReview(caseId:string){const{reviews,loaded}=useReviews();return{review:reviews.find(r=>r.caseId===caseId)??null,loaded};}
const REVIEWER_KEY="netsage.reviewer.v1"; export const DEFAULT_REVIEWER="Pushkar Singh";
export function getReviewerName(){if(typeof window==="undefined")return DEFAULT_REVIEWER;return window.localStorage.getItem(REVIEWER_KEY)||DEFAULT_REVIEWER;}
export function setReviewerName(name:string){if(typeof window==="undefined")return;window.localStorage.setItem(REVIEWER_KEY,name);}
export function useReviewerName(){const[name,setNameState]=useState(DEFAULT_REVIEWER);useEffect(()=>{setNameState(getReviewerName());},[]);
const setName=useCallback((next:string)=>{setNameState(next);setReviewerName(next);},[]);return[name,setName] as const;}
export const QUICK_COMMENTS=["Diagnosis reviewed and accepted.","Evidence supports the stated root cause.","Corrected after comparing with lab evidence.","Rejected — root cause not supported by evidence."];
