import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { CASE_BY_ID } from "@/data/cases";
import { runRules } from "@/lib/rules";
import type { Diagnosis } from "@/lib/types";

const DiagnoseInput=z.object({caseId:z.string()});
export interface DiagnoseResult{diagnosis:Diagnosis;ruleTrace:{id:string;explain:string;weight:number}[];}

export const diagnoseCase=createServerFn({method:"POST"}).inputValidator((input:unknown)=>DiagnoseInput.parse(input)).handler(async({data}):Promise<DiagnoseResult>=>{
  const c=CASE_BY_ID.get(data.caseId);
  if(!c)throw new Error(`Unknown case ${data.caseId}`);
  const rules=runRules(c);
  const ruleTrace=rules.matched.map(r=>({id:r.id,explain:r.explain,weight:r.weight}));
  return{diagnosis:rules.diagnosis,ruleTrace};
});
