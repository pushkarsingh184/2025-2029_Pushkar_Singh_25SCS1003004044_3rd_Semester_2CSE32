#!/usr/bin/env python3
"""Small deterministic companion checker for NetSage AI submission.

Input JSON example:
{
  "host_ip": "10.10.0.44",
  "host_mask": "255.255.255.0",
  "gateway": "10.10.0.1",
  "expected_gateway": "10.10.0.1",
  "interface_state": "up",
  "vlan_exists": true,
  "required_vlan_allowed_on_trunk": true,
  "route_exists": true,
  "known_ips": ["10.10.0.10", "10.10.0.44"]
}
"""
import ipaddress, json, sys

def check(cfg):
    issues=[]
    if cfg.get("host_ip") and cfg.get("known_ips"):
        if cfg["host_ip"] in cfg["known_ips"][0:-1]:
            issues.append(("duplicate_ip", "Host IP appears more than once in known IPs."))
    if cfg.get("host_ip") and cfg.get("host_mask") and cfg.get("expected_network"):
        net=ipaddress.ip_network(cfg["expected_network"], strict=False)
        if ipaddress.ip_address(cfg["host_ip"]) not in net:
            issues.append(("wrong_mask_or_network", "Host IP is outside the expected network."))
    if cfg.get("gateway") and cfg.get("expected_gateway") and cfg["gateway"] != cfg["expected_gateway"]:
        issues.append(("gateway_mismatch", "Configured gateway differs from the expected gateway."))
    if str(cfg.get("interface_state","")).lower() in {"down","notconnect","err-disabled","errdisabled"}:
        issues.append(("interface_down", "Interface is not operational."))
    if cfg.get("vlan_exists") is False:
        issues.append(("missing_vlan", "Required VLAN is not present."))
    if cfg.get("required_vlan_allowed_on_trunk") is False:
        issues.append(("missing_trunk_vlan", "Required VLAN is absent from the trunk allowed list."))
    if cfg.get("route_exists") is False:
        issues.append(("missing_route", "Required destination route is absent."))
    return issues

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python rule_checker.py config.json")
        raise SystemExit(2)
    with open(sys.argv[1], encoding="utf-8") as f:
        cfg=json.load(f)
    issues=check(cfg)
    print(json.dumps({"issues": [{"check":a,"message":b} for a,b in issues], "issue_count":len(issues)}, indent=2))
