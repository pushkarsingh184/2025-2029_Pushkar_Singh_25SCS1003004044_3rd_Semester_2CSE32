# NetSage AI — Submission Package

Submission package for the Applied AI + Network Troubleshooting problem.

## Included
- `data/cases.csv` — 35 structured troubleshooting cases covering VLAN, Gateway, DHCP, DNS, Routing, ACL, NAT and Wireless.
- `docs/diagnose_prompt.md` — structured diagnosis prompt.
- `tools/rule_checker.py` — deterministic Python checker.
- `docs/rule_checker.md` — checker and rule documentation.
- `docs/dashboard.xlsx` — case and review summary.
- `docs/responsible_ai_log.md` — recorded human review interventions.
- `source/` — relevant exported application source files.

## Final application review snapshot
- 35/35 cases reviewed
- 30 Accepted
- 4 Edited
- 1 Rejected
- AI/human agreement: 86%
- Rule coverage: 34/35
- Human-corrected cases: 5

The application requires human review before a diagnosis is accepted.
